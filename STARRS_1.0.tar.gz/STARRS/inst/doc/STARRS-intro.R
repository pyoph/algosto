## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----install, eval=FALSE------------------------------------------------------
# install.packages("STARRS")

## ----load---------------------------------------------------------------------
library(STARRS)

## ----example------------------------------------------------------------------
# Load the STARRS package
library(STARRS)
# Generate some example data
data <- rSphereGM(n=500,d=5,K=3)

# Compute the median using the Weiszfeld algorithm
median_est <- WeiszfeldMedian(data$X)
print(median_est)

# Compute the median covariance matrix
medianCov <- WeiszfeldMedianCovariance(data$X,median_est=median_est)
print(medianCov)


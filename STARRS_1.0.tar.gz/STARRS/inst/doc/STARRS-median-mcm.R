## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----echo=TRUE, results='verbatim'--------------------------------------------
N <- 1000
p <- 4
X <- matrix(rnorm(N * p), ncol = p)

# Compute Weiszfeld geometric median
res <- STARRS::WeiszfeldMedian(X)

res

## ----echo=TRUE, results='verbatim'--------------------------------------------
N <- 1000
p <- 4
X <- matrix(rnorm(N * p), ncol = p)

# Compute ASG geometric median
# Ensure the ASGMedian function is available (from STARRS package)
res <- STARRS::ASGMedian(X)

# Display result
res

## ----fig-median, fig.cap="Comparison of the squared errors and computation time between Weiszfeld and ASGD algorithms with respect to the sample size.", out.width="70%", fig.align='center', echo=FALSE,eval=TRUE----
knitr::include_graphics("plot_median.png")

## ----echo=TRUE, results='verbatim'--------------------------------------------
N <- 1000
p <- 4
X <- matrix(rnorm(N * p), ncol = p)

# Compute Weiszfeld geometric median
med_est <- STARRS::WeiszfeldMedian(X)

# Compute the associated Median Covariation Matrix
res <- STARRS::WeiszfeldMedianCovariance(X, median_est = med_est)

res

## ----echo=TRUE, results='verbatim'--------------------------------------------
N <- 1000
p <- 4
X <- matrix(rnorm(N * p), ncol = p)

# Compute the median using ASGMedian
med_est <- STARRS::ASGMedian(X)

# Compute the associated Median Covariation Matrix
res <- STARRS::ASGMedianCovariance(X, median_est = med_est)
res

## ----fig-MCM, ffig.cap="Comparison of the squared errors and computation time between Weiszfeld and ASGD algorithms with respect to the sample size.", out.width="70%", fig.align='center', echo=FALSE,eval=TRUE----
knitr::include_graphics("plot_MCM.png")


## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(mvtnorm)
library(STARRS)

# Generate sample data
N <- 5000
p <- 3
Sigma <- diag(1:p)
X <- mvtnorm::rmvnorm(N, sigma = Sigma)

# Compute offline and online robust variance
Variance_off <- STARRS::offlineRobustVariance(X, computeOutliers = TRUE)
Variance_on <- STARRS::onlineRobustVariance(X,computeOutliers = TRUE)

# Display the estimated covariance
Variance_off$variance
Variance_on$variance

# Detection of outliers
sum(Variance_off$outlier_labels)
sum(Variance_on$outlier_labels)

# MATRICE DE CONFUSION


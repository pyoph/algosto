## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------

# Define the true covariance matrix
Sigma <- diag(2:1)
N <- 5000

# Generate Gaussian data
X <- mvtnorm::rmvnorm(N, sigma = Sigma)

# Compute the geometric median
med <- STARRS::WeiszfeldMedian(X)

# Compute the Median Covariation Matrix (MCM)
MCM <- STARRS::WeiszfeldMedianCovariance(X, median_est = med)

# Extract its eigenvalues
delta <- eigen(MCM)$values
p <- length(delta)

# Generate U = Sigma^{-1/2}(X - mu)
U <- matrix(rnorm(N * p), ncol = p)

# Run the Robbins–Monro estimation
lambda <- STARRS::robbinsMC(U = U, delta = delta, init = delta)

# Display the estimated eigenvalues
lambda

## -----------------------------------------------------------------------------


# Define the true covariance matrix
Sigma <- diag(2:1)
N <- 5000

# Generate Gaussian data
X <- mvtnorm::rmvnorm(N, sigma = Sigma)

# Compute the geometric median
med <- STARRS::WeiszfeldMedian(X)

# Compute the Median Covariation Matrix (MCM)
MCM <- STARRS::WeiszfeldMedianCovariance(X, median_est = med)

# Extract its eigenvalues
delta <- eigen(MCM)$values
p <- length(delta)

# Generate standardized observations U = Σ^{-1/2}(X - μ)
U <- matrix(rnorm(N * p), ncol = p)

# Run the fixed-point estimation
lambda <- STARRS::fixMC(U = U, delta = delta, init = delta)

# Display the estimated eigenvalues
lambda
 

## -----------------------------------------------------------------------------
# Load required packages
library(mvtnorm)
library(STARRS)

# Define the true covariance matrix
Sigma <- diag(2:1)
N <- 5000

# Generate Gaussian data
X <- mvtnorm::rmvnorm(N, sigma = Sigma)

# Compute the geometric median
med <- STARRS::WeiszfeldMedian(X)

# Compute the Median Covariation Matrix (MCM)
MCM <- STARRS::WeiszfeldMedianCovariance(X, median_est = med)

# Extract eigenvalues of the MCM
delta <- eigen(MCM)$values
p <- length(delta)

# Generate standardized observations
U <- matrix(rnorm(N * p), ncol = p)

# Run the gradient algorithm
lambda <- STARRS::gradMC(U = U, delta = delta, init = delta)

# Display the estimated eigenvalues
lambda

## ----fig-vp, fig.cap='Comparison of the squared errors and computational time between the three methods (Robbins–Monro, Gradient, and Fixed-point) as a function of the sample size.', out.width="70%", fig.align='center', echo=FALSE,eval=TRUE----
knitr::include_graphics("plot_vp.png")

## -----------------------------------------------------------------------------
library(mvtnorm)
library(STARRS)

# Generate sample data
N <- 5000
p <- 3
Sigma <- diag(1:p)
X <- mvtnorm::rmvnorm(N, sigma = Sigma)

# Compute offline robust variance
Variance <- STARRS::onlineRobustVariance(X)

# Display the estimated covariance
Variance$variance

## -----------------------------------------------------------------------------
library(mvtnorm)
library(STARRS)

# Generate sample data
N <- 5000
p <- 3
Sigma <- diag(1:p)
X <- mvtnorm::rmvnorm(N, sigma = Sigma)

# Compute online robust variance
Variance <- STARRS::onlineRobustVariance(X)

# Display the estimated covariance
Variance$variance

## ----fig-variance, echo=FALSE, fig.cap="Comparison of the different methods for estimating robustly the variance", out.width="50%"----
knitr::include_graphics("plot_variance_N.png")


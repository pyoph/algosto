#' @title Gradient descent for the estimation of the eigen values of the variance-covariance matrix
#'
#' @description Given the eigen values \eqn{\delta} of the median covariation matrix, this function estimates
#' the eigen values \eqn{\lambda} of a variance-covariance matrix using the gradient descent method.
#'
#' @param U Matrix of size N*p corresponding to \eqn{\Sigma^{-1/2}(X-\mu)}. The rows are the observations.
#'
#' - In a gaussian model typically `U = matrix(rnorm(N*p),ncol=p)`
#' - In a Student model `U <- matrix(rnorm(N*p)/sqrt(rchisq(1,df=df))*sqrt((df-2)), ncol=p))`
#' - In a Laplace model `U <- LaplacesDemon::rmvl(N,mu=rep(0,p),Sigma=diag(p))`
#' @param delta Vector of size p of the eigen values of the median covariation matrix
#' @param init Initial value of the vector of eigen values of the variance-covariance matrix, by default equal to delta
#' @param niter Maximum number of iterations for the gradient descent algorithm, by default 10
#' @param epsilon Stopping criterion: the algorithm stops when the difference between two iterations is less than epsilon, by default 1e-08
#' @param step Step of the gradient descent, by default 1
#' @param out_index Indexes of the iterations for which we want to output the values of the estimates, default is the last iteration
#'
#' @return A list containing the estimated eigen values \eqn{\lambda}, the number of iterations,
#' and the values of the estimates for different iterations
#'
#' @md
#'
#' @examples
#' delta <- c(1, 1)
#' N <- 1000
#' p <- length(delta)
#' U <- matrix(rnorm(N*p),ncol=p)
#' gradMC(U=U,delta=delta)
#'
#' @export
#'
#'
gradMC <- function(U,delta,init=delta,niter=10,epsilon=1e-08,step=rep(1,niter),out_index=niter)
{
  return(gradMCRcpp(U,delta,init,niter,epsilon,step,out_index))
}


#' @title Fix point method for the estimation of the eigen values of the variance-covariance matrix
#'
#' @description Given the eigen values \eqn{\delta} of the median covariation matrix, this function estimates
#' the eigen values \eqn{\lambda} of a variance-covariance matrix using the fix point method.
#'
#' @param U Matrix of size N*p corresponding to \eqn{\Sigma^{-1/2}(X-\mu)}. The rows are the observations.
#'
#' - In a gaussian model typically `U = matrix(rnorm(N*p),ncol=p)`
#' - In a Student model `U <- matrix(rnorm(N*p)/sqrt(rchisq(1,df=df))*sqrt((df-2)), ncol=p))`
#' - In a Laplace model `U <- LaplacesDemon::rmvl(N,mu=rep(0,p),Sigma=diag(p))`
#' @param delta Vector of size p of the eigen values of the median covariation matrix
#' @param init Initial value of the vector of eigen values of the variance-covariance matrix, by default equal to delta
#' @param niter Maximum number of iterations for the gradient descent algorithm, by default 10
#' @param epsilon Stopping criterion: the algorithm stops when the difference between two iterations is less than epsilon, by default 1e-08
#' @param out_index Indexes of the iterations for which we want to output the values of the estimates, default is the last iteration
#'
#' @return A list containing the estimated eigen values \eqn{\lambda}, the number of iterations,
#' and the values of the estimates for different iterations
#'
#' @md
#'
#' @examples
#' delta <- c(1, 1)
#' N <- 1000
#' p <- length(delta)
#' U <- matrix(rnorm(N*p),ncol=p)
#' fixMC(U=U,delta=delta)
#'
#' @export
#'
fixMC <- function(U,delta,init=delta,niter=10,epsilon=1e-08,out_index=niter)
{
  return(fixMCRcpp(U,delta,init,niter,epsilon,out_index))
}


#' @title Robbins-Monro method for the estimation of the eigen values of the variance-covariance matrix
#'
#' @description Given the eigen values \eqn{\delta} of the median covariation matrix, this function estimates
#' the eigen values \eqn{\lambda} of a variance-covariance matrix using the Robbins-Monro method.
#'
#' @param U Matrix of size N*p corresponding to \eqn{\Sigma^{-1/2}(X-\mu)}. The rows are the observations.
#'
#' - In a gaussian model typically `U = matrix(rnorm(N*p),ncol=p)`
#' - In a Student model `U <- matrix(rnorm(N*p)/sqrt(rchisq(1,df=df))*sqrt((df-2)), ncol=p))`
#' - In a Laplace model `U <- LaplacesDemon::rmvl(N,mu=rep(0,p),Sigma=diag(p))`
#' @param delta Vector of size p of the eigen values of the median covariation matrix
#' @param init Initial value of the vector of eigen values of the variance-covariance matrix, by default equal to delta
#' @param gamma Robbins-Monro parameter (0.75 by default)
#' @param c Robbins-Monro parameter (2 by default)
#' @param w Robbins-Monro parameter (2 by default)
#' @param init_bar, A VOIR AVEC DAPHNE: c'est un extraparamèetre dont on se sert pour l'estimation en ligne, on est obligé de le donner?
#' @param c_bar, A VOIR AVEC DAPHNE: c'est un extraparamèetre dont on se sert pour l'estimation en ligne, on est obligé de le donner?
#' @param c_tilde, A VOIR AVEC DAPHNE: c'est un extraparamèetre dont on se sert pour l'estimation en ligne, on est obligé de le donner?
#' @param c_bar, A VOIR AVEC DAPHNE: c'est un extraparamèetre dont on se sert pour l'estimation en ligne, on est obligé de le donner?
#' @param sumlog A VOIR AVEC DAPHNE: c'est un extraparamèetre dont on se sert pour l'estimation en ligne, on est obligé de le donner?
#' @param epsilon Stopping criterion: the algorithm stops when the difference between two iterations is less than epsilon, by default 1e-08
#' @param out_index Indexes of the iterations for which we want to output the values of the estimates, default is the number of observations N
#'
#' @return A list containing the estimated eigen values \eqn{\lambda}, the number of iterations,
#' and the values of the estimates for different iterations
#'
#' @md
#'
#' @examples
#' delta <- c(1, 1)
#' N <- 1000
#' p <- length(delta)
#' U <- matrix(rnorm(N*p),ncol=p)
#' robbinsMC(U=U,delta=delta)
#'
#' @export
robbinsMC <- function(U,delta,init=delta,init_bar=delta,
                      gamma=0.75,c=2,w=2,c_bar = 0,c_tilde = 0,sumlog=1,
                      epsilon=1e-08,out_index=dim(U)[1])
{
  # Check on U and delta dimensions
  N <- dim(U)[1]
  p <- dim(U)[2]
  checkmate::checkTRUE(length(delta) == p)
  return(robbinsMCRcpp(U,delta,init,init_bar,
                       gamma,c,w,c_bar,c_tilde,sumlog,
                       epsilon))
}

######################################################################

#' @title Weiszfeld algorithm for the estimation of the median
#'
#' @description Wrapper for the Rcpp function WeiszfeldMedianRcpp
#'
#' @param X Matrix of size N*p corresponding to the data. The rows are the observations.
#' @param init_median Initial value of the median, by default equal to 0
#' @param weights Vector of size N of the weights, by default equal to 1
#' @param epsilon Stopping criterion: the algorithm stops when the difference between two iterations is less than epsilon, by default 1e-08
#' @param nitermax Maximum number of iterations for the Weiszfeld algorithm, by default 100
#'
#' @return A list containing the estimated median and the number of iterations
#'
#' @md
#'
#' @examples
#' N <- 1000
#' p <- 4
#' X <- matrix(rnorm(N*p),ncol=p)
#' WeiszfeldMedian(X)
#'
#' @export
WeiszfeldMedian <- function(X, init_median=rep(0,ncol(X)), weights=rep(1,nrow(X)), epsilon=1e-08, nitermax = 100)
{
  return(WeiszfeldMedianRcpp(X, init_median, weights, epsilon, nitermax))
}

#' @title Weiszfeld algorithm for the estimation of the median covariation matrix
#'
#' @description Wrapper for the Rcpp function WeiszfeldMedianCovarianceRcpp
#'
#' @param X Matrix of size N*p corresponding to the data. The rows are the observations.
#' @param median_est Estimation of the median, typically an output of \link{WeiszfeldMedian}
#' @param init_median_cov Initial value of the median covariation matrix, by default equal to the identity matrix
#' @param weights Vector of size N of the weights, by default equal to 1
#' @param epsilon Stopping criterion: the algorithm stops when the difference between two iterations is less than epsilon, by default 1e-08
#' @param nitermax Maximum number of iterations for the Weiszfeld algorithm, by default 100
#'
#' @return A list containing the estimated median covariation matrix and the number of iterations
#'
#' @md
#'
#' @examples
#' N <- 1000
#' p <- 4
#' X <- matrix(rnorm(N*p),ncol=p)
#' med_est <- WeiszfeldMedian(X)
#' WeiszfeldMedianCovariance(X, median_est=med_est$estimator)
#'
#' @export
WeiszfeldMedianCovariance <- function(X, median_est=WeiszfeldMedian(X)$median, init_median_cov=diag(ncol(X)), weights=rep(1,nrow(X)), epsilon=1e-08, nitermax = 100)
{
  return(WeiszfeldMedianCovarianceRcpp(X, median_est, init_median_cov, weights, epsilon, nitermax))
}

#' @title ASG algorithm for the estimation of the median
#'
#' @description Wrapper for the Rcpp function ASGMedianRcpp
#'
#' @param X Matrix of size N*p corresponding to the data. The rows are the observations.
#' @param init_median Initial value of the median, by default equal to 0
#' @param weights Vector of size N of the weights, by default equal to 1
#' @param gamma ASG parameter (2 by default)
#' @param alpha ASG parameter (0.75 by default)
#' @param nstart Number of starts for the ASG algorithm, by default 1
#' @param epsilon Stopping criterion: the algorithm stops when the difference between two iterations is less than epsilon, by default 1e-08
#'
#' @return A list containing the estimated median and the number of iterations
#'
#' @md
#'
#' @examples
#' N <- 1000
#' p <- 4
#' X <- matrix(rnorm(N*p),ncol=p)
#' ASGMedian(X)
#'
#' @export
ASGMedian <- function(X, init_median=rep(0,ncol(X)), weights=rep(1,nrow(X)), gamma=2, alpha=0.75, nstart=1, epsilon=1e-08)
{
  return(ASGMedianRcpp(X, init_median, weights, gamma, alpha, nstart, epsilon))
}

#' @title ASG algorithm for the estimation of the median covariation matrix
#'
#' @description Wrapper for the Rcpp function ASGMedianCovarianceRcpp
#'
#' @param X Matrix of size N*p corresponding to the data. The rows are the observations.
#' @param median_est Estimation of the median, typically an output of \link{ASGMedian}
#' @param init_median_cov Initial value of the median covariation matrix, by default equal to the identity matrix
#' @param weights Vector of size N of the weights, by default equal to 1
#' @param gamma ASG parameter (2 by default)
#' @param alpha ASG parameter (0.75 by default)
#' @param nstart Number of starts for the ASG algorithm, by default 1
#'
#' @return A list containing the estimated median covariation matrix and the number of iterations
#'
#' @md
#'
#' @examples
#' N <- 1000
#' p <- 4
#' X <- matrix(rnorm(N*p),ncol=p)
#' med <- ASGMedian(X)
#' ASGMedianCovariance(X, median_est=med$estimator)
#'
#' @export
ASGMedianCovariance <- function(X, median_est=ASGMedian(X)$estimator, init_median_cov=diag(ncol(X)), weights=rep(1,nrow(X)), gamma=2, alpha=0.75, nstart=1)
{
  return(ASGMedianCovarianceRcpp(X, median_est, init_median_cov, weights, gamma, alpha, nstart))
}


#' @title Robust PCA using Weiszfeld algorithm
#'
#' @description Robust PCA using Weiszfeld algorithm for the median and the median covariation computation
#'
#' @param X Matrix of size N*p corresponding to the data. The rows are the observations.
#' @param init_median Initial value of the median, by default equal to 0
#' @param init_median_cov Initial value of the median covariation matrix, by default equal to the identity matrix
#' @param weights Vector of size N of the weights, by default equal to 1
#' @param scores Number of scores to compute, by default 2
#' @param epsilon Stopping criterion: the algorithm stops when the difference between two iterations is less than epsilon, by default 1e-08
#' @param nitermax Maximum number of iterations for the Weiszfeld algorithm, by default 100
#'
#' @return A list containing :
#' - `median` : the estimated median
#' - `covmedian` : the estimated median covariation matrix
#' - `scores` : the scores
#' - `vectors`: the eigen vectors
#' - `iterm` : the number of iterations for the median computation
#' - `itercov` : the number of iterations for the median covariation matrix computation
#'
#' @md
#'
#' @examples
#' N <- 1000
#' p <- 4
#' X <- matrix(rnorm(N*p),ncol=p)
#' WeiszfeldRobustPCA(X)
#'
#' @export
WeiszfeldRobustPCA <- function(X, init_median=rep(0,ncol(X)), init_median_cov=(diag(ncol(X))), weights=rep(1,nrow(X)), scores=2, epsilon=1e-08, nitermax = 100)
{
  med <- WeiszfeldMedianRcpp(X, init_median=init_median, weights=weights, epsilon=epsilon, nitermax=nitermax)
  medcovmat <- WeiszfeldMedianCovarianceRcpp(X, init_median_cov=init_median_cov, weights=weights, median_est=med$estimator, epsilon=epsilon, nitermax=nitermax)

  vectors <- RSpectra::eigs_sym(medcovmat$estimator, scores)$vectors
  vscores <- sweep(X,2,med$estimator)%*%vectors

  return(list(median=med$estimator, covmedian=medcovmat$estimator, scores=vscores, vectors=vectors, iterm = med$iter, itercov = medcovmat$iter))
}

#' @title Robust PCA using ASG algorithm
#'
#' @description Robust PCA using ASG algorithm for the median and the median covariation computation
#'
#' @param X Matrix of size N*p corresponding to the data. The rows are the observations.
#' @param init_median Initial value of the median, by default equal to 0
#' @param init_median_cov Initial value of the median covariation matrix, by default equal to the identity matrix
#' @param weights Vector of size N of the weights, by default equal to 1
#' @param epsilon Stopping criterion: the algorithm stops when the difference between two iterations is less than epsilon, by default 1e-08
#' @param scores Number of scores to compute, by default 2
#' @param gamma ASG parameter (2 by default)
#' @param alpha ASG parameter (0.75 by default)
#' @param nstart Number of starts for the ASG algorithm, by default 1
#'
#' @return A list containing :
#'
#' - `median` : the estimated median
#' - `covmedian` : the estimated median covariation matrix
#' - `scores` : the scores
#' - `vectors`: the eigen vectors
#'
#' @md
#'
#' @examples
#' N <- 1000
#' p <- 4
#' X <- matrix(rnorm(N*p),ncol=p)
#' ASGRobustPCA(X)
#'
#' @export
ASGRobustPCA <- function(X, init_median=rep(0,ncol(X)), init_median_cov=diag(ncol(X)), weights=rep(1,nrow(X)), epsilon=1e-08, scores=2, gamma=2, alpha=0.75, nstart=1)
{
  med <- ASGMedianRcpp(X, init_median=init_median, weights=weights, gamma=gamma, alpha=alpha, nstart=nstart, epsilon=epsilon)
  medcovmat <- ASGMedianCovarianceRcpp(X, init_median_cov=init_median_cov, median_est=med$estimator, weights=weights, gamma=gamma, alpha=alpha, nstart=nstart)

  vectors <- RSpectra::eigs_sym(medcovmat$estimator, scores)$vectors
  vscores <- sweep(X,2,med$estimator)%*%vectors

  return(list(median=med$estimator,covmedian=medcovmat$estimator,scores=scores,vectors=vectors))
}

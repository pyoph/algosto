#' Robust Mixture Model
#'
#' Robust EM algorithm for Mixture Model for a fixed number of clusters K
#'
#' @param X A numerical matrix giving the data of size nxd
#' @param K Integer giving the number of clusters
#' @param ninit The number of random initializations (10 by default)
#' @param initClust Initial clustering, typically an output of `mclust::hclass` with a single number of clusters or `genieclust::genie` (`NULL` by default)
#' @param methodMC Method to compute the eigen values and vectors of variance-covariance matrix starting from median covariation matrix, can be "FixMC", "GradMC" or "RobbinsMC" (by default)
#' @param methodMCM Method to compute the geometric median and the median covariation matrix, can be "Weiszfeld" (by default) or "ASG"
#' @param model Type of distribution: can be "Gaussian" (by default), "Student" or "Laplace"
#' @param df Degrees of freedom used when model is 'Student' (`NULL` by default). When used, it must be greater than 3
#' @param nitermax Maximum number of iterations in the geometric median computation using the Weiszfeld algorithm
#' @param niterEM Maximum number of updates in the EM algorithm
#' @param niterMC Maximum number of updates in the gradient descent algorithm in the estimation of the eigen values of the variance-covariance matrix
#' @param mc_sample_size Size of the sample for the Monte Carlo method in the estimation of the eigen values of the variance-covariance matrix
#' @param LogLike Initial value of log likelihood. TODO Si c'est grand, LogLikeEM ne sera jamais plus grand que ca. Pourquoi on le donne en argument ? On pourrait le mettre initialement à 0.
#' @param epsdist Distance between old and new centers after each iteration has to be greater than epsdist
#' @param epsvp Minimal value for eigen values (0 by default)
#' @param epsilon Stopping criterion used in the Weiszfeld geometric median computation and in the estimation of the eigen values of the variance-covariance matrix
#' @param gamma Robbins-Monro parameter for eigen values estimation, if methodMCM="RobbinsMC"
#' @param c Robbins-Monro parameter for eigen values estimation, if methodMCM="RobbinsMC". When parameter `scale=TRUE`, `c=1` should be a good choice.
#' @param w Robbins-Monro parameter for eigen values estimation, if methodMCM="RobbinsMC"
#' @param scale Boolean value for scaling data before running the algorithm (`FALSE` by default)
#' @param eps_tau Small correction to avoid 0 and 1 values of tau (1e-04 by default)
#' @param logPhiTol Tolerance for small values of log densities (-20 by default). This must be a negative value, since the log densities are first adjusted by substracting their max.
#' @param outlierThreshold Threshold for outliers detection, on a log density criterion (-20 by default)
#'
#' @return description TODO
#'
#' @seealso \link{multipleRobustMM}
#'
#' @references \url{https://cnrs.hal.science/hal-03853744/}
#' @references Cardot, H., Cenac, P. and Zitt, P-A. (2013). Efficient and fast estimation of the geometric median in Hilbert spaces with an averaged stochastic gradient algorithm. \emph{Bernoulli}, 19, 18-43.
#' @references Cardot, H. and Godichon-Baggioni, A. (2017). Fast Estimation of the Median Covariation Matrix with Application to Online Robust Principal Components Analysis.  \emph{Test}, 26(3), 461-480
#' @references Vardi, Y. and Zhang, C.-H. (2000). The multivariate L1-median and associated data depth. \emph{Proc. Natl. Acad. Sci. USA}, 97(4):1423-1426.
#'
#' @examples
#' \donttest{
#'
#' }
#'
#' @export
#' @md
robustMM <- function(X,K=2,ninit=10,initClust=NULL,
                     methodMC="RobbinsMC",methodMCM="Weiszfeld",model="Gaussian",df=NULL,
                     nitermax=50,niterEM=50,niterMC=50,
                     mc_sample_size=1000,LogLike=-1e10,epsdist=1e-04,epsvp=0,epsilon=1e-03,
                     gamma=0.75,c=ncol(X),w=2,
                     scale=FALSE,
                     eps_tau=1e-04,
                     logPhiTol=-20,
                     outlierThreshold=-20
)
{
  # Arguments check
  checkmate::assertChoice(methodMC, c("RobbinsMC", "GradMC", "FixMC"))
  checkmate::assertChoice(methodMCM, c("Weiszfeld", "Weiszfeld_init", "ASG", "ASG_init"))
  checkmate::assert_logical(scale)
  checkmate::assertChoice(model, c("Gaussian", "Student", "Laplace"))
  if (model == "Student"){
    checkmate::assertInt(df, lower = 3)
  }
  if (ninit <= 0 && is.null(initClust))
    stop("Either ninit>0 or initClust != NULL")

  # Robust scaling with median and MAD (median absolute deviation) if asked
  if (scale==TRUE){
    X <- DescTools::RobScale(X)
    robCenters <- attr(X,"scaled:center")
    robScales <- attr(X,"scaled:scale")
    c <- 1
  }

  # Initialisation
  d <- ncol(X)
  n <- nrow(X)

  finalcenters <- matrix(0,nrow=K,ncol=d)
  finalcluster <- matrix(0,nrow=n,ncol=K)
  logPhi <- matrix(0,nrow=n,ncol=K) # log densities \log \phi_ik
  finalPhiik <- matrix(0,nrow=n,ncol=K)
  finalvar <- matrix(0,nrow=d,ncol=K*d)
  finalprop <- rep(0,K) # pi_k
  finalniter <- 0
  finaloutliers <- c()

  # If an initial clustering was given
  if (!is.null(initClust)){
    prop <- rep(1/K,K) # initial proportion of individuals in each cluster
    # TODO question : est ce que je ne remplace pas par ca :
    #prop <- sapply(1:K, function(k) sum(initClust==k))
    #prop <- prop/sum(prop)

    # tau is a probability but we start with a one hot encoding of the given clustering
    # (probability 1 of being in a cluster and 0 to be in all the others)
    # TODO comme plus tard c'est ce qu'on veut eviter, ca ne pose pas de pb ?
    tau <- matrix(0,nrow=n,ncol=K)
    for (k in 1:K){
      I <- which(initClust==k)
      tau[I,k] <- 1
    }

    centers <- matrix(0,ncol=d,nrow=K) # pourquoi pas aléatoire dans X comme plus bas ? parce que j'ai une init et que j'ai des premiers tau que je vais donner au calcul de mediane

    # Initialisation of Sigma and V
    Sigma <- matrix(rep(diag(d),K),nrow=d)
    V <- matrix(rep(diag(d),K),nrow=d)

    l <- 0

    dist <- 1e10
    epsout <- -20

    while (l < niterEM && dist > epsdist){
      l <- l+1
      old_centers <- centers

      # Update centers, variances and weights
      res <- update(K , d, tau, methodMCM, X, centers, Sigma, V, nitermax, epsilon, methodMC, mc_sample_size, gamma, w, c, niterMC, model, df, epsvp)
      centers <- res$centers
      Sigma <- res$Sigma
      V <- res$V
      prop <- res$prop

      dist <- sum((old_centers-centers)^2)/(K*d)
      # TODO a voir si on ne fait pas plutot un test sur tau

      # Compute logdensity logPhi
      for (k in 1 : K){
        centers_k <- centers[k,,drop=FALSE]
        var_k <- Sigma[,((k-1)*d+1):(k*d)]

        if (model=="Gaussian")
          logPhi[,k] <- mvtnorm::dmvnorm(X,mean=centers_k,sigma=var_k,log=TRUE)
        else if(model=="Student")
          logPhi[,k] <- mvtnorm::dmvt(X,delta=centers_k,sigma=(df-2)/df*var_k,df=df,log=TRUE)
        else # model=="Laplace"
          logPhi[,k] <- LaplacesDemon::dmvl(X,mu=centers_k,Sigma=var_k,log=TRUE)
      }

      # Update tau with proper adjustments
      tau <- logPhi

      # Avoid exp to be zero or NaN for at least one element (no change on final tau since equivalent to multiply and divide by the same constant)
      tau <- tau - apply(tau,1,max)

      # Avoid too small values (change on final tau, but only for values which contribute less than exp(logPhiTol) in the sum)
      tau[tau<logPhiTol] <- logPhiTol

      # Effective tau update
      for (k in 1:K)
        tau[,k] <- prop[k]*exp(tau[,k] ) # Probabilities of belonging to cluster k
      tau <- tau/rowSums(tau) # tau is a probability

      # TODO verifier si il y en a qui valent NaN
      if (any(is.na(tau)))
        cat('tau has NaN values : i=',K,o,l,'\n')

      # Avoid tau to be 0 or 1, to avoid tau getting stuck
      tau <- tau+eps_tau
      tau <- tau/rowSums(tau)
    } # end of while (l < niterEM && dist > epsdist)

    # Detect outliers
    outliers <- c()
    max_logPhi <- apply(logPhi,1,max)
    outliers <- which(max_logPhi<=outlierThreshold) # this criteria could be improved (PhD Paul)

    # Avoid log densities to be too small
    # TODO attention, une fois on l'utilise après soustraction du max
    # et ici sans avoir enleve le max...
    logPhi[logPhi<logPhiTol] <- logPhiTol

    entropy <- - sum(tau*log(tau + (tau==0)))
    LogLikeEM <- sum(tau*logPhi)+ sum(tau*log(prop)) + entropy

    if (all(!is.na(LogLikeEM)) && LogLikeEM > LogLike){ # TODO ca arrive is.na(LogLikeEM)?
      finalcenters <- centers
      finalcluster <- tau
      finalvar <- Sigma
      finalPhiik <- logPhi
      LogLike <- LogLikeEM
      finalniter <- l
      finalprop <- prop
      finaloutliers <- outliers
    }
  } # end of if (!is.null(initClust))

  if (ninit > 0){
    for (o in 1:ninit){
      # Initialisation
      prop <- rep(1/K,K)

      # Tau initialisation
      tau <- matrix(1,nrow=n,ncol=K)

      # Centers, Sigma and V initialisation
      centers <- as.matrix(X[sample(1:n,K),, drop=FALSE],ncol=d) # centers initialisation with random points of X
      Sigma <- matrix(rep(diag(d),K),nrow=d)
      V <- matrix(rep(diag(d),K),nrow=d)

      l <- 0
      dist <- 1e10

      # EM
      while (l < niterEM && dist > epsdist)
      {
        l <- l+1

        # Update probabilities
        for (k in 1 : K){
          centers_k <- centers[k,, drop=FALSE]
          var_k <- Sigma[,((k-1)*d+1):(k*d)]

          if (model=="Gaussian")
            logPhi[,k] <- mvtnorm::dmvnorm(X,mean=centers_k,sigma=var_k,log=TRUE)
          else if(model=="Student")
            logPhi[,k] <- mvtnorm::dmvt(X,delta=centers_k,sigma=(df-2)/df*var_k,df=df,log=TRUE)
          else # model=="Laplace"
            logPhi[,k] <- LaplacesDemon::dmvl(X,mu=centers_k,Sigma=var_k,log=TRUE)
        }

        # Update tau, with proper adjustments
        tau <- logPhi
        tau <- tau - apply(tau,1,max)
        tau[tau<logPhiTol] <- logPhiTol

        for (k in 1:K)
          tau[,k] <- prop[k]*exp(tau[,k] )
        tau <- tau/rowSums(tau)

        tau <- tau+eps_tau
        tau <- tau/rowSums(tau)

        old_centers <- centers

        # Update centers, variances and weights
        res <- update(K , d, tau, methodMCM, X, centers, Sigma, V, nitermax, epsilon, methodMC, mc_sample_size, gamma, w, c, niterMC, model, df, epsvp)
        centers <- res$centers
        Sigma <- res$Sigma
        V <- res$V
        prop <- res$prop

        dist <- sum((old_centers-centers)^2)/(K*d)
      } # end of while (l < niterEM && dist > epsdist)

      # Detect outliers
      outliers <- c()
      max_logPhi <- apply(logPhi,1,max)
      outliers <- which(max_logPhi<=outlierThreshold)

      # Avoid log densities to be too small
      logPhi[logPhi<logPhiTol] <- logPhiTol

      entropy <- - sum(tau*log(tau + (tau==0)))
      LogLikeEM <- sum(tau*logPhi)+ sum(tau*log(prop)) + entropy

      # TODO à quoi ca sert ?
      if (all(!is.na(LogLikeEM)) && LogLikeEM > LogLike){
        finalcenters <- centers
        finalcluster <- tau
        finalvar <- Sigma
        LogLike <- LogLikeEM
        finalniter <- l
        finalPhiik <- logPhi
        finalprop <- prop
        finaloutliers <- outliers
      }
    } # end of for (o in 1:ninit)
  } # end of if (ninit > 0)

  # convert back with scaling (unscale output)
  if (scale==TRUE){
    for (k in 1:K){
      finalvar[,((k-1)*d+1):(k*d)] <- diag(robScales)%*%finalvar[,((k-1)*d+1):(k*d)]%*%diag(robScales)
      finalcenters[k,] <- finalcenters[k,]%*%diag(robScales)+ robCenters
    }
  }

  clusters <- apply(finalcluster,1,which.max)

  return(list(centers=finalcenters,Sigma=finalvar,Loglike=LogLike,entropy=entropy, tau=finalcluster,clusters=clusters,niter=finalniter,initEM=initClust,prop=finalprop,outliers=finaloutliers))
}


#' @keywords internal
update <- function(K , d, tau, methodMCM, X, centers, Sigma, V, nitermax, epsilon, methodMC, mc_sample_size, gamma, w, c, niterMC, model, df, epsvp){
  prop <- rep(0, K)

  for (k in 1:K){
    if(any(tau[,k]>0)){
      prop[k] <- mean(tau[,k])
      if (methodMCM=="Weiszfeld_init"){
        med <- WeiszfeldMedian(X, init_median=centers[k,,drop=FALSE], weights=(tau[,k])/sum(tau[,k]), epsilon = epsilon, nitermax = nitermax)
        medcovmat <- WeiszfeldMedianCovariance(X, median_est = med$estimator, init_median_cov=V[,((k-1)*d+1):(k*d)], weights=(tau[,k])/sum(tau[,k]), epsilon = epsilon, nitermax = nitermax)
      }
      else if (methodMCM=="Weiszfeld"){
        med <- WeiszfeldMedian(X, weights=(tau[,k])/sum(tau[,k]), epsilon = epsilon, nitermax = nitermax)
        medcovmat <- WeiszfeldMedianCovariance(X, median_est = med$estimator, weights=(tau[,k])/sum(tau[,k]), epsilon = epsilon, nitermax = nitermax)
      }
      else if (methodMCM=="ASG_init"){
        med <- ASGMedian(X, init_median=centers[k,,drop=FALSE], weights=(tau[,k]))
        medcovmat <- ASGMedianCovariance(X, median_est = med$estimator, init_median_cov=V[,((k-1)*d+1):(k*d)], weights=(tau[,k]))
      }
      else if (methodMCM=="ASG"){
        med <- ASGMedian(X, weights=(tau[,k]))
        medcovmat <- ASGMedianCovariance(X, median_est = med$estimator, weights=(tau[,k]))
      }

      if (all(!is.na(medcovmat$estimator)) && all(is.finite(medcovmat$estimator))){
        centers[k,] <- med$estimator
        eig <- eigen(medcovmat$estimator)
        eigenvec <- eig$vectors  # vecteur propre de \hat V du papier
        eigenval <- eig$values  # delta du papier

        # Generate U for eigen values computation
        p <- length(eigenval)

        if(model == 'Gaussian'){
          U = matrix(rnorm(mc_sample_size*p),ncol=p)
        }
        else if(model == 'Student'){
          U <- matrix(rnorm(mc_sample_size*p)/sqrt(rchisq(1,df=df))*sqrt(df-2), ncol=p)
        }
        else{ # model == 'Laplace'
          U <- LaplacesDemon::rmvl(mc_sample_size,mu=rep(0,p),Sigma=diag(p))
        }

        # Compute eigen values of variance-covariance matrix using eigen values of median-covariation matrix by Monte Carlo
        if (methodMC=="RobbinsMC"){
          eigen_est <- robbinsMC(U=U,delta=eigenval,gamma=gamma,c=c,w=w,epsilon=epsilon,
                                 init=eigenval,init_bar=eigenval)
        }
        else if (methodMC=="GradMC"){
          eigen_est <- gradMC(U=U,delta=eigenval,niter=niterMC,epsilon=epsilon,step=c*(1:niterMC)^(-0.5))
        }
        else if (methodMC=="FixMC"){
          eigen_est <- fixMC(U=U,delta=eigenval,niter=niterMC,epsilon=epsilon)
        }

        lambdak <- c(pmax(eigen_est$vp,epsvp))

        # Update Sigma_k and V_k
        Sigma[,((k-1)*d+1):(k*d)] <- t(matrix(eigenvec,ncol=d,byrow=T))%*%diag(lambdak)%*%(matrix(eigenvec,ncol=d,byrow=T)) # calcul de \psi(\hat V)
        V[,((k-1)*d+1):(k*d)] <- medcovmat$estimator
      }
    }
  }
  return(list(centers=centers, Sigma=Sigma, V=V, prop=prop))
}

#' Robust Mixture Model
#'
#' Robust EM algorithm for Mixture Model for a number of clusters in a range
#'
#' @param X A numerical matrix giving the data of size nxd
#' @param nclust Range of number of clusters
#' @param ninit The number of random initializations (10 by default)
#' @param init Kind of initialization, can be 'Mclust' (default) or 'genie'
#' @param methodMC Method to compute the eigen values and vectors of variance-covariance matrix starting from median covariation matrix, can be "FixMC", "GradMC" or "RobbinsMC" (by default)
#' @param methodMCM Method to compute the geometric median and the median covariation matrix, can be "Weiszfeld" (by default) or "ASG"
#' @param model Type of distribution: can be "Gaussian" (by default), "Student" or "Laplace"
#' @param df Degrees of freedom used when model is 'Student' (NULL by default). When used, it must be greater than 3
#' @param nitermax Maximum number of iterations in the geometric median computation using the Weiszfeld algorithm
#' @param niterEM Maximum number of updates in the EM algorithm
#' @param niterMC Maximum number of updates in the gradient descent algorithm in the estimation of the eigen values of the variance-covariance matrix
#' @param mc_sample_size Size of the sample for the Monte Carlo method in the estimation of the eigen values of the variance-covariance matrix
#' @param LogLike Initial value of log likelihood. TODO Si c'est grand, LogLikeEM ne sera jamais plus grand que ca. Pourquoi on le donne en argument ? On pourrait le mettre initialement à 0.
#' @param epsdist Distance between old and new centers after each iteration has to be greater than epsdist
#' @param epsvp Minimal value for eigen values (0 by default)
#' @param epsilon Stopping criterion used in the Weiszfeld geometric median computation and in the estimation of the eigen values of the variance-covariance matrix
#' @param gamma Robbins-Monro parameter for eigen values estimation, if methodMCM="RobbinsMC"
#' @param c Robbins-Monro parameter for eigen values estimation, if methodMCM="RobbinsMC". When parameter scale=TRUE, c=1 should be a good choice.
#' @param w Robbins-Monro parameter for eigen values estimation, if methodMCM="RobbinsMC"
#' @param scale Boolean value for scaling data before running the algorithm (FALSE by default)
#' @param criterion Criterion for choice of best clustering, can be 'ICL'  or 'BIC' (default)
#' @param nb_cores Number of cores in parallel computation, by default parallel::detectCores()
#' @param eps_tau Small correction to avoid 0 and 1 values in tau computation (1e-04 by default)
#' @param logPhiTol Tolerance for small values of log densities (-20 by default)
#' @param outlierThreshold Threshold for outliers detection (-20 by default)
#'
#'
#' @return List of results from a robust EM algorithm for Mixture Model :
#'  - `allresults` : list of all results
#'  - `bestresult` : best result, according to the chosen criterion
#'  - `ICL` : list of ICL criterions computed on each result in allresults
#'  - `BIC` : list of BIC criterions computed on each result in allresults
#'  - `data` : original data
#'  - `nclust` : range of explored numbers of clusters
#'  - `Kopt` : optimal number of clusters according to the chosen `criterion`
#'
#' @seealso \link{robustMM}
#'
#' @references \url{https://cnrs.hal.science/hal-03853744/}
#' @references Cardot, H., Cenac, P. and Zitt, P-A. (2013). Efficient and fast estimation of the geometric median in Hilbert spaces with an averaged stochastic gradient algorithm. \emph{Bernoulli}, 19, 18-43.
#' @references Cardot, H. and Godichon-Baggioni, A. (2017). Fast Estimation of the Median Covariation Matrix with Application to Online Robust Principal Components Analysis.  \emph{Test}, 26(3), 461-480
#' @references Vardi, Y. and Zhang, C.-H. (2000). The multivariate L1-median and associated data depth. \emph{Proc. Natl. Acad. Sci. USA}, 97(4):1423-1426.

#' @examples
#' \donttest{
#'
#' }
#'
#' @export
#' @md
multipleRobustMM <- function(X,
                             nclust=2:5,
                             ninit=10,
                             init='Mclust',
                             methodMC="RobbinsMC",methodMCM="Weiszfeld",model="Gaussian",df=NULL,
                             nitermax=50,niterEM=50,niterMC=50,
                             mc_sample_size=1000,LogLike=-1e10,epsdist=1e-04,epsvp=0,epsilon=1e-03,
                             gamma=0.75,c=ncol(X),w=2,
                             scale=FALSE,
                             criterion='BIC',
                             nb_cores = parallel::detectCores(),
                             eps_tau = 1e-04,
                             logPhiTol = -20,
                             outlierThreshold = -20)
{
  # Arguments check
  checkmate::assertIntegerish(nclust)
  checkmate::assertChoice(methodMC, c("RobbinsMC", "GradMC", "FixMC"))
  checkmate::assertChoice(methodMCM, c("Weiszfeld", "Weiszfeld_init", "ASG", "ASG_init"))
  checkmate::assert_logical(scale)
  checkmate::assertChoice(model, c("Gaussian", "Student", "Laplace"))
  if (model == "Student"){
    checkmate::assertInt(df, lower = 3)
  }

  checkmate::assertChoice(init, c('Mclust', 'genie'), null.ok=TRUE)
  checkmate::assertChoice(criterion, c('ICL', 'BIC'))
  checkmate::assertInt(nb_cores, upper = parallel::detectCores())

  initClust <- NULL

  ICL <- c()
  BIC <- c()

  if (length(nclust)==1)
  {
    Kopt <- nclust

    if (init=='Mclust'){
      clas <- mclust::hcVVV(data=X)
      initClust <- mclust::hclass(clas,nclust)
    }
    # else init=='genie'
    else {
      initClust <- genieclust::genie(X,k=nclust)
    }

    resultat <- robustMM(X,K=nclust,ninit=ninit,nitermax=nitermax,niterEM=niterEM,epsvp=epsvp,
                         niterMC=niterMC,mc_sample_size=mc_sample_size,LogLike=LogLike,initClust=initClust,
                         gamma=gamma,c=c,w=w,epsilon=epsilon,methodMC=methodMC,methodMCM=methodMCM,scale=scale, model=model, df=df,
                         eps_tau=eps_tau, logPhiTol=logPhiTol, outlierThreshold=outlierThreshold)

    bestresult <- resultat

    penality <- 0.5*log(nrow(X))*(nclust-1+ nclust*ncol(X) + nclust*ncol(X)*(ncol(X)+1)/2)
    ICL <- c(ICL, bestresult$Loglike - penality - bestresult$entropy)
    BIC <- c(BIC, bestresult$Loglike - penality)
  } # end of if (length(nclust)==1)

  else if (length(nclust)>1)
  {
    # if (par==TRUE)
    #  {
    future::plan(future::multisession, workers = nb_cores)

    resultat <- foreach::foreach(K=nclust, .options.future = list(seed = TRUE))  %dofuture%
      {
        if (init=='Mclust'){
          clas <- mclust::hcVVV(data=X)
          initClust <- mclust::hclass(clas,K)
        } #else if (init=='genie')
        else {
          initClust <- genieclust::genie(X,k=K)
        }
        #         cat('Running for : K=',K,'\n') TODO faire marcher ce print
        #          cat("Running K =", min(nclust), "...\n")
        resultatk <- robustMM(X,K=K,ninit=ninit,nitermax=nitermax,niterEM=niterEM,epsvp=epsvp,
                              niterMC=niterMC,mc_sample_size=mc_sample_size, LogLike=LogLike,initClust=initClust,
                              gamma=gamma,c=c,w=w,epsilon=epsilon,methodMC=methodMC,methodMCM=methodMCM,scale=scale,
                              model=model, df=df, eps_tau=eps_tau, logPhiTol=logPhiTol, outlierThreshold=outlierThreshold)
        return(resultatk)
      } # end of foreach::foreach(...) %dofuture%
    # } # end of if (par == TRUE)

    # else {
    #   resultat <- foreach::foreach(K=nclust)  %do%
    #     {
    #       if (init=='Mclust'){
    #         clas <- mclust::hcVVV(data=X)
    #         initClust <- mclust::hclass(clas,nclust)
    #       }
    #       else if (init=='genie'){
    #         initClust <- genieclust::genie(X,k=K)
    #       }
    #       resultatk <- robustMM(X,K=K,ninit=ninit,nitermax=nitermax,niterEM=niterEM,epsvp=epsvp,
    #                            niterMC=niterMC,mc_sample_size=mc_sample_size, LogLike=LogLike,initClust=initClust,
    #                            gamma=gamma,c=c,w=w,epsilon=epsilon,methodMC=methodMC,methodMCM=methodMCM,scale=scale, model=model, df=df)
    #       return(resultatk)
    #     }
    # } # end of if (par == FALSE)

    for (k in 1:length(nclust)){
      penality <- 0.5*log(nrow(X))*(nclust[k]-1+ nclust[k]*ncol(X) + nclust[k]*ncol(X)*(ncol(X)+1)/2)
      ICL <- c(ICL,resultat[[k]]$Loglike - penality - resultat[[k]]$entropy)
      BIC <- c(BIC,resultat[[k]]$Loglike - penality)
    }
    if (criterion=='ICL'){
      k <- which.max(ICL)
      Kopt <- nclust[k]
    }
    else if (criterion=='BIC'){
      k <- which.max(BIC)
      Kopt <- nclust[k]
    }
    bestresult <- resultat[[k]]
  }

  RMM_res <- list(allresults=resultat,bestresult=bestresult,ICL=ICL,BIC=BIC,data=X,nclust=nclust,Kopt=Kopt)

  class(RMM_res) <- "RMM"
  return(RMM_res)

  #return(list(allresults=resultat,bestresult=bestresult,ICL=ICL,BIC=BIC,data=X,nclust=nclust,Kopt=Kopt))
}


#' @keywords internal
RobVar <- function(X,methodMC='Robbins', methodMCM='Weiszfeld', model='Gaussian',
                   init_median=rep(0,ncol(X)),
                   init_median_cov=diag(ncol(X)),
                   epsMCM=1e-08,niterWeisz=50,
                   gammaMCM=2, alphaMCM=0.75, nstart=1,
                   mc_sample_size=1000,
                   df=3, epsilon=1e-08,
                   niterMC=50,
                   c=2, gamma=0.75, w=2)
{
  d <- ncol(X)
  if(methodMCM=='Weiszfeld'){
    median <- WeiszfeldMedian(X=X, init_median=init_median, epsilon=epsMCM, nitermax=niterWeisz)
    medianCov <- WeiszfeldMedianCovariance(X=X, median_est=median$estimator, init_median_cov=init_median_cov, epsilon=epsMCM, nitermax=niterWeisz)
  }
  else if(methodMCM=='ASG')
  {
    median <- ASGMedian(X=X, init_median=init_median, gamma=gammaMCM, alpha=alphaMCM, nstart=nstart, epsilon=epsMCM)
    medianCov <- ASGMedianCovariance(X=X, median_est=median$estimator, init_median_cov=init_median_cov, gamma=gammaMCM, alpha=alphaMCM, nstart=nstart)
  }
  eig <- eigen(medianCov$estimator)
  eigenvec <- eig$vectors
  eigenval <- eig$values

  # Generate U for eigen values computation
  p <- length(eigenval)

  if(model == 'Gaussian'){
    U = matrix(rnorm(mc_sample_size*p),ncol=p)
  }
  else if(model == 'Student'){
    U <- matrix(rnorm(mc_sample_size*p)/sqrt(rchisq(1,df=df))*sqrt(df-2), ncol=p)
  }
  else{ # model == 'Laplace'
    U <- LaplacesDemon::rmvl(mc_sample_size,mu=rep(0,p),Sigma=diag(p))
  }

  # Compute eigen values of variance-covariance matrix using eigen values of median-covariation matrix
  if (methodMC=="RobbinsMC"){
    eigen_est <- robbinsMC(U=U,delta=eigenval,gamma=gamma,c=c,w=w,epsilon=epsilon,
                           init=delta,init_bar=eigenval)
  }
  else if (methodMC=="GradMC"){
    eigen_est <- gradMC(U=U,delta=eigenval,niter=niterMC,epsilon=epsilon,step=c*(1:niterMC)^(-0.5))
  }
  else if (methodMC=="FixMC"){
    eigen_est <- fixMC(U=U,delta=eigenval,niter=niterMC,epsilon=epsilon)
  }

  lambda <- c(eigen_est$vp)
  variance <- t(matrix(eigenvec,ncol=d,byrow=TRUE))%*%diag(lambda)%*%(matrix(eigenvec,ncol=d,byrow=TRUE))
  resultat <- list(median=median$estimator,variance=variance,covmedian=medianCov$estimator)
  return(resultat)
}

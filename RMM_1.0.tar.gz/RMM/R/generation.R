# ------------------------------------------------------------------------------
# Gaussian mixture model with contamination
# ------------------------------------------------------------------------------

#' @title Generation of Gaussian distribution with contamination
#'
#' @description This function generates a sample of size 3*n from 3 Gaussian distribution in \eqn{\mathbf{R}^d}
#' with means 0, 3 and -3
#' and variance-covariance matrices \eqn{\Sigma_1 = 2 I_d}, \eqn{\Sigma_2 = diag(1:d)} and \eqn{\Sigma_3 = diag((1:d)^{-1})}.
#' The sample is contaminated with a proportion pcont of uniform or Student contamination.
#'
#' @param n Size of the sample
#' @param d Dimension of the sample
#' @param pcont Proportion of contamination
#' @param df Degrees of freedom of the Student contamination
#' @param cont Type of contamination: can be "Student" or "Unif"
#' @param min Minimum value of the contamination
#' @param max Maximum value of the contamination
#'
#' @return A list containing the sample X and the classification classif
#'
#' @examples
#' data <- rContaminatedGMM(n=500,d=5,pcont=0.1,df=1,cont="Student",min=-5,max=5)
#'
#' @export
rContaminatedGMM <- function(n=500,d=5,pcont=0,df=1,cont="Student",min=-5,max=5){
  checkmate::assertChoice(cont, c("Student", "Unif"))

  # GMM with 3 gaussians
  mean <- rep(0,d)
  Sigma <- diag(d)*2
  X <- mvtnorm::rmvnorm(n,mean=mean,sigma=Sigma)
  Tclassif <- rep(1,n)

  mean <- rep(3,d)
  Sigma <- diag(1:d)
  X <- rbind(X,mvtnorm::rmvnorm(n,mean=mean,sigma=Sigma))
  Tclassif=c(Tclassif,rep(2,n))

  mean <- -rep(3,d)
  Sigma <- diag((1:d)^(-1))
  X <- rbind(X,mvtnorm::rmvnorm(n,mean=mean,sigma=Sigma))
  Tclassif=c(Tclassif,rep(3,n))

  # Contamination
  if (pcont>0)
  {
    if(cont=='Unif')
    {
      Z <- matrix(runif(pcont*n*d,min,max),ncol=d)
    }
    if (cont=='Student')
    {
      Z <- matrix(rt(pcont*n*d,df=df),ncol=d)
    }
    I <- sample(1:(3*n),size=pcont*n)
    X[I,] <- Z
    Tclassif[I] <- "outliers"
  }

  # Shuffle
  mel <- sample.int(3*n)
  Tclassif <- Tclassif[mel]
  X <- X[mel,]
  return(list(X=X,classif=Tclassif))
}

#' @title Generation of Gaussian mixture distribution with Student contamination
#'
#' @description Function to generate a sample of a gaussian mixture model with Student contamination
#' \eqn{X\sim \sum_{k=1}^K \pi_k Y_k}, where \eqn{Y_k\sim \mathcal N (\mu_k, \Sigma_k)}.
#'
#' @param nk Vector of the number of observations in each component, giving the proportions \eqn{\pi_k}
#' @param muG Matrix of the means of the Gaussian components \eqn{\mu = (\mu_1, \ldots, \mu_K)} TODO plutot array
#' @param sigmaG Array of the variance-covariance matrices of the Gaussian components
#' @param delta Proportion of contamination
#' @param dfT Degrees of freedom of the Student contamination
#' @param muT Matrix of the means of the Student contamination
#' @param sigmaT Array of the variances of the Student contamination
#'
#' @return A list containing the sample X, the indicator of contamination C and the latent variable Z, giving the classification
#'
#' @export
rGMMcontStudent <- function(nk, muG, sigmaG, delta, dfT, muT, sigmaT){
  K <- length(nk); p <- ncol(muG); n <- sum(nk)
  nkCum <- c(0, cumsum(nk))
  nkG <- round(nk*(1-delta)); nkA <- nk - nkG
  Z <- C <- rep(0, n); X <- matrix(NA, n, p)
  for(k in 1:K){
    if(nkA[k] > 0){
      X[nkCum[k]+(1:nk[k]), ] <-
        rbind(mvtnorm::rmvnorm(n=nkG[k], mean=muG[k, ], sigma=sigmaG[k, , ]),
              mvtnorm::rmvt(n=nkA[k], delta=muT[k, ], sigma=sigmaT[k, , ], df=dfT))
      C[nkCum[k]+nkG[k]+(1:nkA[k])] <- 1
    }else{
      X[nkCum[k]+(1:nk[k]), ] <-
        mvtnorm::rmvnorm(n=nk[k], mean=muG[k, ], sigma=sigmaG[k, , ])
    }
    Z[nkCum[k]+(1:nk[k])] <- k
  }
  randOrder <- rank(runif(n)); Z <- Z[randOrder]; C <- C[randOrder]; X <- X[randOrder, ];
  return(list(Z=Z, C=C, X=X))
}

#' @title Generation of Gaussian mixture distribution with uniform contamination
#'
#' @description Function to generate a sample of a gaussian mixture model with uniform contamination
#' \eqn{X\sim \sum_{k=1}^K \pi_k Y_k}, where \eqn{Y_k\sim \mathcal N (\mu_k, \Sigma_k)}.
#'
#' @param nk Vector of the number of observations in each component, giving the proportions \eqn{\pi_k}
#' @param muG Matrix of the means of the Gaussian components \eqn{\mu = (\mu_1, \ldots, \mu_K)} TODO plutot array
#' @param sigmaG Array of the variance-covariance matrices of the Gaussian components
#' @param delta Proportion of contamination
#' @param lUnif Vector of lower bounds of the uniform contamination
#' @param uUnif Vector of upper bounds of the uniform contamination
#'
#' @return A list containing the sample X, the indicator of contamination C and the latent variable Z, giving the classification
#'
#' @export
rGMMcontUniform <- function(nk, muG, sigmaG, delta, lUnif, uUnif){
  # muG <- parm$muG; sigmaG <- parm$sigmaG; lUnif <- parm$lUnif; uUnif <- parm$uUnif
  # nk = vecteur des effectifs des composantes
  # muG = matrice des moyennes par composantes
  # sigmaG = 'array' des variances par composantes
  # delta = taux de contamination
  # lUnif = vecteur des bornes inf des uniformes contaminantes
  # uUnif = vecteur des bornes sup des uniformes contaminantes
  K <- length(nk); p <- ncol(muG); n <- sum(nk)
  nkCum <- c(0, cumsum(nk))
  nkG <- round(nk*(1-delta)); nkA <- nk - nkG
  Z <- C <- rep(0, n); X <- matrix(NA, n, p)
  for(k in 1:K){
    if(nkA[k] > 0){
      X[nkCum[k]+(1:nk[k]), ] <-
        rbind(mvtnorm::rmvnorm(n=nkG[k], mean=muG[k, ], sigma=sigmaG[k, , ]),
              sapply(1:p, function(j){runif(n=nkA[k], min=lUnif[j], max=uUnif[j])}))
      C[nkCum[k]+nkG[k]+(1:nkA[k])] <- 1
    }else{
      X[nkCum[k]+(1:nk[k]), ] <-
        mvtnorm::rmvnorm(n=nk[k], mean=muG[k, ], sigma=sigmaG[k, , ])
    }
    Z[nkCum[k]+(1:nk[k])] <- k
  }
  randOrder <- rank(runif(n)); Z <- Z[randOrder]; C <- C[randOrder]; X <- X[randOrder, ];
  return(list(Z=Z, C=C, X=X))
}

# ------------------------------------------------------------------------------
# Student mixture model with contamination
# ------------------------------------------------------------------------------

#' @title Generation of Student distribution with contamination
#'
#' @description This function generates a sample of size 3*n from 3 Student distribution in \eqn{\mathbf{R}^d}
#' with means 0, 3 and -3
#' and variance-covariance matrices \eqn{\Sigma_1 = 2 I_d}, \eqn{\Sigma_2 = diag(1:d)} and \eqn{\Sigma_3 = diag((1:d)^{-1})}.
#' The sample is contaminated with a proportion pcont of uniform or Student contamination.
#'
#' @param n Size of the sample
#' @param d Dimension of the sample
#' @param pcont Proportion of contamination
#' @param df Degrees of freedom of the Student distribution
#' @param dfcont Degrees of freedom of the Student contamination
#' @param cont Type of contamination: can be "Student" or "Unif"
#' @param min Minimum value of the contamination
#' @param max Maximum value of the contamination
#'
#' @return A list containing the sample X and the classification classif
#'
#' @examples
#' data <- rContaminatedTMM(n=500,d=5,pcont=0.1,df=3,dfcont=1,cont="Student",min=-5,max=5)
#'
#' @export
rContaminatedTMM <- function(n=500,d=5,pcont=0,df=3,dfcont=1,cont="Student",min=-5,max=5)
{
  Sigma= (diag(d)*2)
  X=c()
  Tclassif=c()
  mean=rep(0,d)

  X=mvtnorm::rmvt(n,delta=mean,sigma=(df-2)/df*Sigma,df=df)

  Tclassif=c(Tclassif,rep(1,n))
  Sigma=diag( (1:d))
  mean=rep(3,d)
  X=rbind(X,mvtnorm::rmvt(n,delta=mean,sigma=(df-2)/df*Sigma,df=df))

  Tclassif=c(Tclassif,rep(2,n))

  Sigma=  (diag((1:d)^(-1)))
  mean=- rep(3,d)
  X=rbind(X,mvtnorm::rmvt(n,delta=mean,sigma=(df-2)/df*Sigma,df=df))
  Tclassif=c(Tclassif,rep(3,n))

  if (pcont>0)
  {
    if(cont=='Unif')
    {
      Z=matrix(runif(pcont*n*d,min,max),ncol=d)
    }
    if (cont=='Student')
    {
      Z=matrix(rt(pcont*n*d,df=dfcont),ncol=d)
    }
    I=sample(1:(3*n),size=pcont*n)
    X[I,]=Z
    Tclassif[I]="outliers"
  }


  mel=sample.int(3*n)
  Tclassif=Tclassif[mel]
  X=X[mel,]
  return(list(X=X,classif=Tclassif))
}

#' @title Generation of Student mixture distribution with Student contamination
#'
#' @description Function to generate a sample of a Student mixture model with Student contamination
#' \eqn{X\sim \sum_{k=1}^K \pi_k Y_k}, where \eqn{Y_k} follow a Student distribution with means \eqn{\mu = (\mu_1, \ldots, \mu_K)}
#' and variance-covaraince matrices \eqn{\Sigma = (\Sigma_1, \ldots, \Sigma_K)}.
#'
#' @param nk Vector of the number of observations in each component, giving the proportions \eqn{\pi_k}
#' @param dfT0 Degrees of freedom of the Student distribution
#' @param muT0 Matrix of the means of the Student distribution
#' @param sigmaT0 Array of the variances of the Student distribution
#' @param delta Proportion of contamination
#' @param dfT1 Degrees of freedom of the Student contamination
#' @param muT1 Matrix of the means of the Student contamination
#' @param sigmaT1 Array of the variances of the Student contamination
#'
#' @return A list containing the sample X, the indicator of contamination C and the latent variable Z, giving the classification
#'
#' @export
rTMMcontStudent <- function(nk, dfT0, muT0, sigmaT0, delta, dfT1, muT1, sigmaT1){
  K <- length(nk); p <- ncol(muT0); n <- sum(nk)
  nkCum <- c(0, cumsum(nk))
  nkT0 <- round(nk*(1-delta)); nkA <- nk - nkT0
  Z <- C <- rep(0, n); X <- matrix(NA, n, p)
  for(k in 1:K){
    if(nkA[k] > 0){
      X[nkCum[k]+(1:nk[k]), ] <-
        rbind(mvtnorm::rmvt(n=nkT0[k], delta=muT0[k, ], sigma=sigmaT0[k, , ], df=dfT0),
              mvtnorm::rmvt(n=nkA[k], delta=muT1[k, ], sigma=sigmaT1[k, , ], df=dfT1))
      C[nkCum[k]+nkT0[k]+(1:nkA[k])] <- 1
    }else{
      X[nkCum[k]+(1:nk[k]), ] <-
        mvtnorm::rmvt(n=nk[k], delta=muT0[k, ], sigma=sigmaT0[k, , ], df=dfT0)
    }
    Z[nkCum[k]+(1:nk[k])] <- k
  }
  randOrder <- rank(runif(n)); Z <- Z[randOrder]; C <- C[randOrder]; X <- X[randOrder, ];
  return(list(Z=Z, C=C, X=X))
}


#' @title Generation of Student mixture distribution with uniform contamination
#'
#' @description Function to generate a sample of a Student mixture model with uniform contamination
#' \eqn{X\sim \sum_{k=1}^K \pi_k Y_k}, where \eqn{Y_k} follow a Student distribution with means \eqn{\mu = (\mu_1, \ldots, \mu_K)}
#' and variance-covaraince matrices \eqn{\Sigma = (\Sigma_1, \ldots, \Sigma_K)}.
#'
#' @param nk Vector of the number of observations in each component, giving the proportions \eqn{\pi_k}
#' @param dfT Degrees of freedom of the Student distribution
#' @param muT Matrix of the means of the Student distribution
#' @param sigmaT Array of the variances of the Student distribution
#' @param delta Proportion of contamination
#' @param lUnif Vector of lower bounds of the uniform contamination
#' @param uUnif Vector of uppers bounds of the uniform contamination
#'
#' @return A list containing the sample X, the indicator of contamination C and the latent variable Z, giving the classification
#'
#' @export
rTMMcontUniform <- function(nk, dfT, muT, sigmaT, delta, lUnif, uUnif){
  K <- length(nk); p <- ncol(muT); n <- sum(nk)
  nkCum <- c(0, cumsum(nk))
  nkT <- round(nk*(1-delta)); nkA <- nk - nkT
  Z <- C <- rep(0, n); X <- matrix(NA, n, p)
  for(k in 1:K){
    if(nkA[k] > 0){
      X[nkCum[k]+(1:nk[k]), ] <-
        rbind(mvtnorm::rmvt(n=nkT[k], delta=muT[k, ], sigma=sigmaT[k, , ], df=dfT),
              sapply(1:p, function(j){runif(n=nkA[k], min=lUnif[j], max=uUnif[j])}))
      C[nkCum[k]+nkT[k]+(1:nkA[k])] <- 1
    }else{
      X[nkCum[k]+(1:nk[k]), ] <-
        mvtnorm::rmvt(n=nk[k], delta=muT[k, ], sigma=sigmaT[k, , ], df=dfT)
    }
    Z[nkCum[k]+(1:nk[k])] <- k
  }
  randOrder <- rank(runif(n)); Z <- Z[randOrder]; C <- C[randOrder]; X <- X[randOrder, ];
  return(list(Z=Z, C=C, X=X))
}

# ------------------------------------------------------------------------------
# Laplace mixture model with contamination
# ------------------------------------------------------------------------------

#
#
#

#' @title Generation mixture model distribution with contamination
#'
#' @description Function to generate a sample of a mixture model with contamination
#'
#' @param nk Vector of the number of observations in each component, giving the proportions \eqn{\pi_k}
#' @param df Degrees of freedom of the Student distribution
#' @param mu Matrix of the means of the distribution (Gaussian or Student)
#' @param Sigma Array of the variances of the distribution (Gaussian or Student)
#' @param delta Proportion of contamination
#' @param cont Type of contamination: can be "Student" or "Unif"
#' @param model Type of distribution: can be "Student" or "Gaussian"
#' @param dfcont Degrees of freedom of the Student contamination
#' @param mucont Matrix of the means of the Student contamination
#' @param Sigmacont Array of the variances of the Student contamination
#' @param minU Vector of lower bounds of the uniform contamination
#' @param maxU Vector of upper bounds of the uniform contamination
#'
#' @return A list containing the sample X, the indicator of contamination C and the latent variable Z, giving the classification
#'
#' @export
rMM <- function(nk=NA, df=3, mu=NA, Sigma=FALSE, delta=0,cont="Student",
                model="Gaussian", dfcont=1, mucont=FALSE, Sigmacont=FALSE, minU=-20, maxU=20)
{
  if (length(is.na(nk)) ==1)
  {
    if (is.na(nk)==TRUE)
    {
      if (is.matrix(mu)==FALSE)
      {
        nk=rep(500,3)
      }
      if (is.matrix(mu) != FALSE)
      {
        nk=rep(500,nrow(mu))
      }
    }
  }
  if (is.matrix(mu)==FALSE)
  {
    mu=c()
    for (i in 1:length(nk))
    {
      Z=rnorm(3)
      mu=rbind(mu,Z)
    }
  }
  if (is.matrix(mucont)==FALSE)
  {
    mucont=mu
  }
  if (is.array(Sigma)==FALSE)
  {
    p=ncol(mu)
    Sigma <- array(dim=c(length(nk), p, p))
    for (i in 1:length(nk))
    {
      Sigma[i, ,]=diag(p)
    }
  }
  if (is.array(Sigmacont)==FALSE)
  {
    Sigmacont=Sigma
  }


  if (cont=="Student")
  {
    if (model=="Student")
    {
      resultat=rTMMcontStudent(nk=nk, dfT0=df, muT0=mu, sigmaT0=Sigma,
                               delta=delta, dfT1=dfcont,
                               muT1=mucont, sigmaT1=Sigmacont)
    }
    if (model=='Gaussian')
    {
      resultat=rGMMcontStudent(nk=nk, muG=mu, sigmaG=Sigma,
                               delta=delta, dfT=dfcont,
                               muT=mucont, sigmaT=Sigmacont)
    }
  }
  if (cont=="Unif")
  {
    if (model=="Student")
    {
      resultat=rTMMcontUniform(nk=nk, dfT=df, muT=mu, sigmaT=Sigma,
                               delta=delta, lUnif=minU, uUnif=maxU)
    }
    if (model=="Gaussian")
    {
      resultat=rGMMcontUniform(nk=nk, muG=mu, sigmaG=Sigma,
                               delta=delta, lUnif=minU, uUnif=maxU)
    }
  }
  return(resultat)
}
